# how to run 

* run server first
* then run client
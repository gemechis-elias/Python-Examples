# Bloom Filter for python


* source code: https://github.com/jaybaird/python-bloomfilter/
* support only python2 as my experiment
* installation: pip install pybloom




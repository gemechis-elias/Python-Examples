import os


files_and_dirs = os.listdir('C:\\')# files and directories at current dir.
print('files_and_dirs: {0}'.format(files_and_dirs))
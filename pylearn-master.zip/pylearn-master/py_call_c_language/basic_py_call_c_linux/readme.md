# How to run

* compile c program to so

```
gcc -c -fPIC libtest.c
gcc -shared libtest.o -o libtest.so
```

* call c from python 

```
python main.py
```



# Ref

* https://coolshell.cn/articles/671.html




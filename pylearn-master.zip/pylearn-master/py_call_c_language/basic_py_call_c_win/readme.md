# How to run

* compile c program to dll

```
cl -LD libtest.c -libtest.dll
```

* call c from python (32bit-python)

```
python main.py
```



# Ref

* https://coolshell.cn/articles/671.html




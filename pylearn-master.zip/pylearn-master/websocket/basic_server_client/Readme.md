# how to run the code

* python3.5
* windows-10
* `pip install websockets`
* `pip install asyncio`
* run server `python ws_server.py`
* run client `python ws_client.py`
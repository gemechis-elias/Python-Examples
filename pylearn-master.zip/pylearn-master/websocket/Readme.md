# Basic about WebSocket

1. What is WebSocket?
   * WebSocket is a computer communications protocol
   
2. Why we need WebSocket since we already has HTTP?
   * both WebSocket and HTTP are depend on TCP
   * the communication can only be started by client for HTTP
   * server can send information to client for WebSocket


# Install WebSocket

* python3.5
* windows-10
* `pip install websockets`






import datetime

datetime_object1 = datetime.datetime.strptime('Jun 1 2018', '%b %d %Y')
datetime_object2 = datetime.datetime.strptime('Jun 1 2018', '%b %d %Y')
datetime_object3 = datetime.datetime.strptime('Jun 1 2018', '%b %d %Y')


print(datetime_object1)
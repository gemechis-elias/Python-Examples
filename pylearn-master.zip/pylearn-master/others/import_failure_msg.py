if __name__ == '__main__':

    try: import matplotlib.pyplot as plt
    except: print 'Must install matplotlib to run this demo.\n'

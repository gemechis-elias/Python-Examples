matrix = [  [1,2,3,4],
            [2,2,3,4],
            [4,2,3,4],
            [3,2,3,4]]

matrix.sort(key=lambda tup: tup[0])# sort by item[0]

print(matrix)


x = 3.14
y = "hello"

if(isinstance(x, float)):
    print('x is float')
    
if(not isinstance(y, float)):
    print('y is not float')

s1 = 'this is a book with a cat'
s2 = 'is'
s1.count(s2)# output 2


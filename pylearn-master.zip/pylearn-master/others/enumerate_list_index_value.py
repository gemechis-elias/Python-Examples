l = [2,2,3,4]

for (index,value) in enumerate(l):
    print(index,value)
for i in range(20):
    dst = '{0:02d}'.format(i) # parameter-0, 0x format
    print(dst)
n,m = map(int, input().split())
x_list = list(map(int, input().split()))

print(n,m)
print(x_list)

'''
6 7
1 2 3 4 5
6 7
[1, 2, 3, 4, 5]
'''
s = 'hello\nworld'
print(s)
'''
hello
world
'''

s1 = repr(s)# useful-tips: repr to treat \n as 2 characters
print(s1)
'''
'hello\nworld'
'''


import sys
sys.path.append('../../../xxxyyyzzz/')
from xxxyyyzzz import func
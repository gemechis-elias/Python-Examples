

print( '   hello '.strip() )# hello
print( '   hello.+- '.strip() )# hello.+-
print( '   hello.+- '.strip('+.- ') )# hello


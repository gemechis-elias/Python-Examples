# configparser read parameters from config file with comment


## Python 3.6.1

[Add comment to config file by ";"](config.ini)

[Read parameters directly](read_cfg_with_comment_by_py36.py)




# How to install configparser at Python3

```python
pip install configparser
```





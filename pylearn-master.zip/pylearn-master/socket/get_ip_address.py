import socket

ip = socket.gethostbyname(socket.gethostname())
print(ip)

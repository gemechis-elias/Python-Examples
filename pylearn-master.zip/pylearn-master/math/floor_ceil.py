import math


print(math.floor(3.1))
print(math.ceil(3.1))

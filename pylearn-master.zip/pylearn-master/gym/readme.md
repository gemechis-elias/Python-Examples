gym
----


# 1. how to get start

* install gym by pip
* start from here https://gym.openai.com/docs/


# 2. Basic

* [no ai game](basic/no_ai_gym.py)
* [CartPole env details](basic/cart_pole_init_details.py)
* [CartPole observation,action,reward,done details](basic/cart_pole_more_details.py)
* [MountainCar-v0 details](basic/mountain_car_more_details.py)
* [more gym env & examples](https://gym.openai.com/envs/)


# 3. more gym environments

* here: https://gym.openai.com/envs/




__author__ = 'Bin Yin (ybdesire@gmail.com)'
__date__ = '2016-06-23'
__version_info__ = (0, 0, 0)
__version__ = '.'.join(str(i) for i in __version_info__)



# How to run the code


* run server by python `python rest_server_cors.py`
* run web server by `python -m http.server`
* access http://127.0.0.1:8000/ at web-browser, then you will access index.html
* click Get button



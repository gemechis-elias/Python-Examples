import webview

webview.create_window("Hi Baidu!", "http://baidu.com")

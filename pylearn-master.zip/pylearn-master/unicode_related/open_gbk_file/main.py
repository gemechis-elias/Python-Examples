with open('sample.txt', 'r', encoding='utf-8') as fr:
    str = fr.readline()
    print(str)




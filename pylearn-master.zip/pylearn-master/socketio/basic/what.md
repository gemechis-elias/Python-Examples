# what is socketio?

* a lib
* Socket.IO enables real-time bidirectional event-based communication



# why socketio?

* for real time web applications, such as games.
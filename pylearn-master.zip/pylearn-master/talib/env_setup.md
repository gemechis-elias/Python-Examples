# install talib on ubuntu


```
$ wget http://prdownloads.sourceforge.net/ta-lib/ta-lib-0.4.0-src.tar.gz
$ tar -xzf ta-lib-0.4.0-src.tar.gz
$ cd ta-lib/
$ ./configure --prefix=/usr
$ make
$ sudo make install
$ pip install TA-Lib
```


# import by python


```
import talib
```

# reference

* https://www.fmz.com/bbs-topic/1234





# package the nn.py to exe

* py2 environment is better
* windows environment
* there is almost no 3rd lib at nn.py


# Steps

* install pyinstaller by pip
* run `pyinstaller nn.py`
* the get `nn.exe` at dist/nn
* copy `train.csv` and `test.csv` to `nn.exe` path, then run exe directly at cmd


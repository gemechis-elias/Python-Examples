def added(x, y):
    return x+y+10
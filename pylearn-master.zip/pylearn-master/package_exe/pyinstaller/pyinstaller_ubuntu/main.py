from myadd import added




x = 1
y = 2
z = added(x,y)
print('final result is {0}'.format(z))


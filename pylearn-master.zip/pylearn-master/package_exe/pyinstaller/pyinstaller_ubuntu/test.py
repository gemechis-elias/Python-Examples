import subprocess


output = subprocess.getstatusoutput('./main')
print(output)
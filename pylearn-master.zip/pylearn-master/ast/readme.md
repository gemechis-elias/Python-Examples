# How to install ast


* python2

```
pip install ast
```


* python3

```
pip install typed-ast
```
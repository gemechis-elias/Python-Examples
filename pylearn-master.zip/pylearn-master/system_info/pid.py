import os
pid = os.getpid()
print('pid={0}'.format(pid))
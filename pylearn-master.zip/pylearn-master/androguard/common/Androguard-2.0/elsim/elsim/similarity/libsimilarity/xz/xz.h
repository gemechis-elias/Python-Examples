#ifndef _XZ_H                                                                                                                                                           
#define _XZ_H

#include <stdio.h>
#include <stdlib.h>

int xzCompress(int, const unsigned char *, size_t, unsigned char *, size_t *);

#endif

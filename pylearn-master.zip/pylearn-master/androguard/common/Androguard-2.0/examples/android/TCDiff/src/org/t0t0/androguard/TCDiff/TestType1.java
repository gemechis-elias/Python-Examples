package org.t0t0.androguard.TCDiff;                                                                                                                                                                                                   

public class TestType1 
{
   public TestType1()
   {
      long long_tc1 = 42;
      long long_tc2 = -42;
      long long_tc3 = 0;

      int int_tc1 = 42;
      int int_tc2 = -42;
      int int_tc3 = 0;

      double double_tc1 = 42.0;
      double double_tc2 = -42.0;
      double double_tc3 = 0.0;

      float float_tc1 = 42.0f;
      float float_tc2 = -42.0f;
      float float_tc3 = 0.0f;
   }
}

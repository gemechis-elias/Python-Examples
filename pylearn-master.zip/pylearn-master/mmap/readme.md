# 1. what is mmap ?

* map file content to memroy

# 2. why mmap ?

* big file
* frequently read/write

# 3. demo

* [basic mmap read/write](mmp_r_w.py)
* [parse bin file by byte accessing](byte_access.py)


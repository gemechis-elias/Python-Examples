stack = [1,2,3]
stack.append(4)# push
stack.append(5)# push
stack.append(6)# push
# pop
x = stack.pop()
print(x)# 6
x = stack.pop()
print(x)# 5
# current stack
print(stack)# [1,2,3,4]
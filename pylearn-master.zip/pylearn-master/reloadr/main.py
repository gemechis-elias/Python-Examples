from mypkg import fun
import time

while(True):
    print(fun(3))
    time.sleep(5)
    
    
    
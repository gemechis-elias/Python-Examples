# hot update python code


1. install reloadr

* https://github.com/hoh/reloadr


2. run main.py


3. modify code at mypkg.py, no need to stop main.py


4. the updated code will be auto reloaded at main.py


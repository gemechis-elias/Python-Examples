# 1. how to install

```
pip install timeout-decorator
```


# 2. ref

* https://github.com/pnpnpn/timeout-decorator



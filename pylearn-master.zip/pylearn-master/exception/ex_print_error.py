try:
    x = 1+1
    y = x/0
    z = 2+2

except Exception as e:
    print(e)